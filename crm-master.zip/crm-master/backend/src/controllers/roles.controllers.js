const rolescontrol = {}
//mostrar varios
rolescontrol.getRoles = (req, res)=>{
   
    res.send("hola");
    console.log("entro")
}
//mostrar uno
rolescontrol.getRol = (req, res)=>{
   
    res.send("hola");
    console.log("entro")
}
//crear uno
rolescontrol.createRol = (req, res)=>{
   
    res.send("hola");
    console.log("entro")
}






module.exports = rolescontrol;