import React, { Component } from 'react'

export default class Votantes extends Component {
    render() {
        return (
            <div>
               votantes 
            </div>
        )
    }
}
